/// <reference path="_all.ts" />

module ContactManagerApp {
  angular.module('contactManagerApp', ['ngMaterial'])
    .controller('mainController', MainController);
}