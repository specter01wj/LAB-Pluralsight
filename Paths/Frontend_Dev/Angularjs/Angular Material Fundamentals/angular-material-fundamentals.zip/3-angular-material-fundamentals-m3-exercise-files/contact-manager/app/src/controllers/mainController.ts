/// <reference path="../_all.ts" />

module ContactManagerApp {
  export class MainController {
    static $inject = [];
    
    constructor() {
    }
    
    message: string = "Hello from our controller";
  }
}