angular.module('app', []);

angular.module('app').controller('Controller1', function($scope) {
  $scope.name = 'Controller 1';
})