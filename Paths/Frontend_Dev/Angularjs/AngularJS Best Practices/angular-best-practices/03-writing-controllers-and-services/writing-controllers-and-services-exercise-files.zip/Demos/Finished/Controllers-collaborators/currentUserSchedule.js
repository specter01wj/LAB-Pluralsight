angular.module('app').service('currentUserSchedule', function(schedule, instructors, currentUser) {

  return {
    // methods & data
  }
})