//angular.module('app').controller('scheduleCtrl',function($scope) {
//  $scope.name = "schedule";
//});

//function scheduleCtrl($scope) {
//  $scope.name = "schedule";
//}
//angular.module('app').controller('scheduleCtrl',scheduleCtrl);

function scheduleCtrl($scope) {
  $scope.name = "schedule";
}

