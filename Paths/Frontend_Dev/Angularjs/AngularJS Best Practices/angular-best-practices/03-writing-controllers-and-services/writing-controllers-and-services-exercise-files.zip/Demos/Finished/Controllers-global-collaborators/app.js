angular.module('app', []);

angular.module('app').value('gData', globalData);

