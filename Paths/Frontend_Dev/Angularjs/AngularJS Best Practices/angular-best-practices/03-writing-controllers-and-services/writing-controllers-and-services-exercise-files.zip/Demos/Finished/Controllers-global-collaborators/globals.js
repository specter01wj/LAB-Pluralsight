var globalData = {
  data : 'global'
};