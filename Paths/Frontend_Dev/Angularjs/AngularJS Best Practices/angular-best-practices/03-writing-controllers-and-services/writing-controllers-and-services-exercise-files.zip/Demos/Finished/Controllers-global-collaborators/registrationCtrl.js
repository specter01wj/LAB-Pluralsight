angular.module('app').controller('registrationCtrl',function($scope, gData) {
  $scope.globalData = gData.data;
});
