var someGlobal = [];
angular.module('app', []);

