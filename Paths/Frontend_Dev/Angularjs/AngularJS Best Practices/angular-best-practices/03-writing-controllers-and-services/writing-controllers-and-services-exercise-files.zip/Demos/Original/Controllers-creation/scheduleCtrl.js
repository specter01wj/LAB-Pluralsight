angular.module('app').controller('scheduleCtrl',function($scope) {
  $scope.name = "schedule";
});
