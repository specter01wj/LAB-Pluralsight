angular.module('app').controller('registrationCtrl',function($scope) {
  $scope.globalData = globalData.data;
});
