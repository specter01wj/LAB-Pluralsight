var app = angular.module('app', []);

app.value('grades', []);

app.controller('userCtrl',function($scope, grades) {
  $scope.GPA = ???

});

