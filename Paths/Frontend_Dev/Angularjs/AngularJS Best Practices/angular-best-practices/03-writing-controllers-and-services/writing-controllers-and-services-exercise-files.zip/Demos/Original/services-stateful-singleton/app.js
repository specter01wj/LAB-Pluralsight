var app = angular.module('app', []);



app.controller('registrationCtrl',function($scope) {
  $scope.availableClasses = [{name:"Chemistry"},{name:"Physics"},{name:"History"},{name:"Biology"},]
//  $scope.schedule = schedule;
});

