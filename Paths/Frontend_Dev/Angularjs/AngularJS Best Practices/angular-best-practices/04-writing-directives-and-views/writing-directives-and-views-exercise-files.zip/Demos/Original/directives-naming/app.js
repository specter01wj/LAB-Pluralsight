var app = angular.module('app', []);

angular.module('app').controller('Controller1',function($scope) {
  $scope.val = "directives!"
});