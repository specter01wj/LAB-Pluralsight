var menu = document.querySelector('#main-nav');
document.querySelector('#menu-trigger').addEventListener('click', function (e) {
  menu.classList.toggle('active');
});
