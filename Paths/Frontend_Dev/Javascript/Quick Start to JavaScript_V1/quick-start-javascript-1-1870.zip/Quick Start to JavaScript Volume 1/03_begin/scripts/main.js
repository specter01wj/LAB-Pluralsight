/*
 * This is a JavaScript Scratchpad.
 *
 * Enter some JavaScript, then Right Click or choose from the Execute Menu:
 * 1. Run to evaluate the selected text (Ctrl+R),
 * 2. Inspect to bring up an Object Inspector on the result (Ctrl+I), or,
 * 3. Display to insert the result in a comment after the selection. (Ctrl+L)
 */

//still need to add semicolon at the end
2 + 2;
2 - 2;

//we can perform harder calculations and let javascript do the hard work
1308480340580845 + 020834028340820348;

//we can multiply
39993 * 2002;

//divide
10000000 / 20;

//also have a funny looking thing called modulo
//divides one value by the second, and returns the leftover amount, or remainder
10%3; //returns 1 since 3 can go in 3 times, and 1 is leftover

//order of operations
30 - 2 * 3;
(30 - 2) * 3; //use parenthesis to make something happen first