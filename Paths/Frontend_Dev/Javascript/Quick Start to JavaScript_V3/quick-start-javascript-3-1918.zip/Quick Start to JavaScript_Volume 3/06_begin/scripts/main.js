function Friend(name) {
  this.name = name;
}
