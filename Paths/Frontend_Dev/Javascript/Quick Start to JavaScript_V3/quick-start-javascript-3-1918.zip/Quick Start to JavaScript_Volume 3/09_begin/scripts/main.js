alert("Hello World!");

function lameJoke(){ 
  randomNumber = Math.round(Math.random() * 2);
   if(randomNumber === 1){
    alert("How many tickles does it take to make an octopus laugh? Ten tickles.");
  } else if (randomNumber === 2) {
     alert("Why did the scarecrow win an award? Because he was outstanding in his field.");
  } else {
    alert("Why did the chicken cross the road? To get to the other side!");
    
  }
}

lameJoke();  