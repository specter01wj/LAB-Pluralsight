# js-dev-env-demo-api
API for JS Dev Env Demo in Pluralsight course
