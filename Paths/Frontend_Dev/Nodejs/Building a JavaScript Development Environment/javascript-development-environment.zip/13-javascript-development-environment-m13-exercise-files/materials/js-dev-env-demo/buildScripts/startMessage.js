import chalk from 'chalk';

console.log(chalk.green('Starting app in dev mode...')); // eslint-disable-line no-console
