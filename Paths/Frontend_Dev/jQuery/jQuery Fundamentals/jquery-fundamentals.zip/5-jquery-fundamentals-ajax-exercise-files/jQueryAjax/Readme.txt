The jQuery Ajax samples can be found in the following folders:

UsingAjax
UsingGet
UsingLoad
UsingPost
UsingSerialize

Visual Studio 2010 or higher is required to run these demos.